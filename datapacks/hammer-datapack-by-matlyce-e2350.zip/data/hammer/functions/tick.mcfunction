# summon item ~ ~ ~ {Item:{id:"minecraft:diamond_pickaxe",Count:1b,tag:{display:{Name:"{\"text\":\"Hammer\",\"italic\":\"false\",\"color\":\"gold\"}"},Unbreakable:1,HideFlags:63,Enchantments:[{id:"minecraft:efficiency",lvl:2}],hammer:1b}}}

# @e[type=item,distance=..1.5,limit=1,nbt={Item:{id:"minecraft:diamond_pickaxe",Count:1b,tag:{display:{Name:"{\"text\":\"Hammer\",\"italic\":\"false\",\"color\":\"gold\"}"},Unbreakable:1,HideFlags:63,Enchantments:[{id:"minecraft:efficiency",lvl:2}],hammer:1b}}}]

execute as @a at @s run function hammer:players

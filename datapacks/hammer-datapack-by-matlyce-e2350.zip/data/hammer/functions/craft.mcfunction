summon item ~ ~ ~ {Item:{id:"minecraft:diamond_pickaxe",Count:1b,tag:{RepairCost:100,display:{Name:"{\"text\":\"Hammer\",\"italic\":\"false\",\"color\":\"gold\"}"},HideFlags:63,Enchantments:[{id:"minecraft:unbreaking",lvl:20},{id:"minecraft:efficiency",lvl:3}],hammer:1b,speed_upgrade:0b,dig_upgrade:0b,smelt_upgrade:0b,mending_upgrade:0b,CustomModelData:16}}}
particle minecraft:ash ~ ~0.1 ~ 0.3 0.2 0.3 0 150 force
playsound minecraft:block.anvil.use player @a[distance=..10] ~ ~ ~ 1 0 0
kill @e[type=item,nbt={Item:{id:"minecraft:gold_block"}},distance=..1]
kill @s

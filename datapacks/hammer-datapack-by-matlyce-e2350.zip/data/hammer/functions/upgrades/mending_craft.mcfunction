data modify entity @s Item.tag.display.Lore insert 0 value '{"text":"Mending I","color":"gray","italic":"false"}'
data modify entity @s Item.tag.Enchantments insert 0 value {lvl:1s,id:"minecraft:mending"}
data modify entity @s Item.tag merge value {mending_upgrade:1b}
execute if data entity @s {Item:{tag:{CustomModelData:16}}} run data modify entity @s Item.tag merge value {CustomModelData:4}

execute if data entity @s {Item:{tag:{dig_upgrade:1b,speed_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:5}
execute if data entity @s {Item:{tag:{dig_upgrade:1b,smelt_upgrade:1b,speed_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:8}
execute if data entity @s {Item:{tag:{dig_upgrade:1b,speed_upgrade:1b,smelt_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:9}
execute if data entity @s {Item:{tag:{dig_upgrade:1b,smelt_upgrade:1b,speed_upgrade:1b}}} run data modify entity @s Item.tag merge value {CustomModelData:10}
execute if data entity @s {Item:{tag:{smelt_upgrade:1b,speed_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:12}
execute if data entity @s {Item:{tag:{speed_upgrade:1b,smelt_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:13}
execute if data entity @s {Item:{tag:{speed_upgrade:1b,smelt_upgrade:1b,dig_upgrade:0b}}} run data modify entity @s Item.tag merge value {CustomModelData:15}

particle minecraft:dust 0 1 0 0.8 ~ ~0.1 ~ 0.3 0.1 0.3 0 20 force
playsound minecraft:entity.player.levelup player @a[distance=..10] ~ ~ ~ 1 0 0
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star"}},distance=..1]
kill @e[type=item,nbt={Item:{id:"minecraft:emerald_block"}},distance=..1]

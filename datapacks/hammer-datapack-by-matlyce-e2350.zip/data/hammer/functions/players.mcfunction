execute as @e[type=item,distance=..5] at @s run function hammer:items
execute if entity @s[nbt={SelectedItem:{id:"minecraft:diamond_pickaxe",Count:1b,tag:{hammer:1b}}}] run function hammer:work/loop

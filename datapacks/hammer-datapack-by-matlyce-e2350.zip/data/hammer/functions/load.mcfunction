scoreboard objectives add break_stone minecraft.mined:minecraft.stone
scoreboard objectives add break_andesite minecraft.mined:minecraft.andesite
scoreboard objectives add break_diorite minecraft.mined:minecraft.diorite
scoreboard objectives add break_granite minecraft.mined:minecraft.granite

scoreboard objectives add break_gravel minecraft.mined:minecraft.gravel
scoreboard objectives add break_dirt minecraft.mined:minecraft.dirt
scoreboard objectives add break_grass minecraft.mined:minecraft.grass_block
scoreboard objectives add break_obsidian minecraft.mined:minecraft.obsidian
scoreboard objectives add break_cobble minecraft.mined:minecraft.cobblestone

scoreboard objectives add break_iron minecraft.mined:minecraft.iron_ore
scoreboard objectives add break_gold minecraft.mined:minecraft.gold_ore
scoreboard objectives add break_coal minecraft.mined:minecraft.coal_ore
scoreboard objectives add break_diamond minecraft.mined:minecraft.diamond_ore
scoreboard objectives add break_emerald minecraft.mined:minecraft.emerald_ore
scoreboard objectives add break_redstone minecraft.mined:minecraft.redstone_ore
scoreboard objectives add break_lapis minecraft.mined:minecraft.lapis_ore

scoreboard objectives add break_netherrack minecraft.mined:minecraft.netherrack
scoreboard objectives add break_nethergold minecraft.mined:minecraft.nether_gold_ore
scoreboard objectives add break_quartz_ore minecraft.mined:minecraft.nether_quartz_ore
scoreboard objectives add break_netherbric minecraft.mined:minecraft.nether_bricks
scoreboard objectives add break_redbrick minecraft.mined:minecraft.red_nether_bricks
scoreboard objectives add break_wartblock minecraft.mined:minecraft.nether_wart_block
scoreboard objectives add break_basalt minecraft.mined:minecraft.basalt

scoreboard objectives add break_cobbled_ds minecraft.mined:minecraft.cobbled_deepslate
scoreboard objectives add break_tuff minecraft.mined:minecraft.tuff
scoreboard objectives add break_ds_iro_ore minecraft.mined:minecraft.deepslate_iron_ore
scoreboard objectives add break_ds_gol_ore minecraft.mined:minecraft.deepslate_gold_ore
scoreboard objectives add break_ds_coa_ore minecraft.mined:minecraft.deepslate_coal_ore
scoreboard objectives add break_ds_dia_ore minecraft.mined:minecraft.deepslate_diamond_ore
scoreboard objectives add break_ds_cop_ore minecraft.mined:minecraft.deepslate_copper_ore
scoreboard objectives add break_ds_eme_ore minecraft.mined:minecraft.deepslate_emerald_ore
scoreboard objectives add break_ds_red_ore minecraft.mined:minecraft.deepslate_redstone_ore
scoreboard objectives add break_chi_ds minecraft.mined:minecraft.chiseled_deepslate
scoreboard objectives add break_ds_lap_ore minecraft.mined:minecraft.deepslate_lapis_ore
scoreboard objectives add break_ds_brick minecraft.mined:minecraft.deepslate_bricks
scoreboard objectives add break_cr_ds_br minecraft.mined:minecraft.cracked_deepslate_bricks
scoreboard objectives add break_pol_ds minecraft.mined:minecraft.polished_deepslate
scoreboard objectives add break_ds minecraft.mined:minecraft.deepslate

# END
scoreboard objectives add break_endst minecraft.mined:minecraft.end_stone


scoreboard objectives add break_total dummy

scoreboard objectives add rotation_x dummy
scoreboard objectives add rotation_y dummy
#scoreboard objectives add rotation_total dummy

scoreboard objectives add absolue dummy
scoreboard players set #-1 absolue -1


# load msg
scoreboard objectives add hammer_hide_msg trigger
scoreboard players add @a hammer_hide_msg 0
scoreboard players enable @a hammer_hide_msg
tellraw @a[scores={hammer_hide_msg=0}] ["",{"text":"[","color":"yellow"},{"text":"HAMMER","italic":true,"color":"gold"},{"text":"]","color":"yellow"},{"text":" Version ","color":"gray"},{"text":"1.19","color":"yellow"},{"text":"+","color":"gold"},{"text":" by","color":"gray"},{"text":" "},{"text":"Matlyce","bold":true,"color":"gray","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/matlyce/submissions/?morder=order_latest"},"hoverEvent":{"action":"show_text","contents":"check out my other datapack creations on Planet Minecraft !"}},{"text":" successfully loaded","color":"dark_green"},{"text":".\n","color":"gray"},{"text":"(hide by clicking here)","italic":true,"color":"gray","clickEvent":{"action":"run_command","value":"/trigger hammer_hide_msg"},"hoverEvent":{"action":"show_text","contents":"Click here to stop receiving this message."}}]

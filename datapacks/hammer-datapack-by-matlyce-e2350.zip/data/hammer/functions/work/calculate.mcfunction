scoreboard players set @s break_total 0
scoreboard players operation @s break_total += @s break_coal
scoreboard players operation @s break_total += @s break_iron
scoreboard players operation @s break_total += @s break_gold
scoreboard players operation @s break_total += @s break_diamond
scoreboard players operation @s break_total += @s break_emerald
scoreboard players operation @s break_total += @s break_lapis
scoreboard players operation @s break_total += @s break_redstone

scoreboard players operation @s break_total += @s break_stone
scoreboard players operation @s break_total += @s break_andesite
scoreboard players operation @s break_total += @s break_diorite
scoreboard players operation @s break_total += @s break_granite

scoreboard players operation @s break_total += @s break_dirt
scoreboard players operation @s break_total += @s break_grass
scoreboard players operation @s break_total += @s break_gravel
scoreboard players operation @s break_total += @s break_obsidian
scoreboard players operation @s break_total += @s break_cobble

scoreboard players operation @s break_total += @s break_netherrack
scoreboard players operation @s break_total += @s break_nethergold
scoreboard players operation @s break_total += @s break_netherbric
scoreboard players operation @s break_total += @s break_quartz_ore
scoreboard players operation @s break_total += @s break_redbrick
scoreboard players operation @s break_total += @s break_wartblock
scoreboard players operation @s break_total += @s break_basalt

# break_cobbled_ds :
# break_tuff :
# break_ds_iro_ore :
# break_ds_gol_ore :
# break_ds_coa_ore :
# break_ds_dia_ore :
# break_ds_cop_ore :
# break_ds_eme_ore :
# break_ds_red_ore :
# break_chi_ds :
# break_ds_lap_ore :
# break_ds_brick :
# break_cr_ds_br :
# break_pol_ds :

scoreboard players operation @s break_total += @s break_cobbled_ds
scoreboard players operation @s break_total += @s break_tuff
scoreboard players operation @s break_total += @s break_ds_iro_ore
scoreboard players operation @s break_total += @s break_ds_gol_ore
scoreboard players operation @s break_total += @s break_ds_coa_ore
scoreboard players operation @s break_total += @s break_ds_dia_ore
scoreboard players operation @s break_total += @s break_ds_cop_ore
scoreboard players operation @s break_total += @s break_ds_eme_ore
scoreboard players operation @s break_total += @s break_ds_red_ore
scoreboard players operation @s break_total += @s break_chi_ds
scoreboard players operation @s break_total += @s break_ds_lap_ore
scoreboard players operation @s break_total += @s break_ds_brick
scoreboard players operation @s break_total += @s break_cr_ds_br
scoreboard players operation @s break_total += @s break_pol_ds
scoreboard players operation @s break_total += @s break_ds


# END
scoreboard players operation @s break_total += @s break_endst



execute store result score @s rotation_x run data get entity @s Rotation.[0]
execute store result score @s rotation_y run data get entity @s Rotation.[1]
#scoreboard players operation ROT_X rotation_total = @s rotation_x
#scoreboard players operation ROT_Y rotation_total = @s rotation_y

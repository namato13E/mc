function hammer:work/dig/modifiers/dig/south
function hammer:work/dig/modifiers/smelt

execute if entity @s[nbt={Item:{id:"minecraft:cobblestone"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:stone",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:cobblestone"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:cobblestone"}}] as @e[nbt={Item:{id:"minecraft:stone"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:iron_ore"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:iron_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:iron_ore"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:iron_ore"}}] as @e[nbt={Item:{id:"minecraft:iron_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:gold_ore"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:gold_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:gold_ore"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:gold_ore"}}] as @e[nbt={Item:{id:"minecraft:gold_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:netherrack"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:nether_bricks",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:netherrack"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:netherrack"}}] as @e[nbt={Item:{id:"minecraft:nether_bricks"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge


execute if entity @s[nbt={Item:{id:"minecraft:cobbled_deepslate"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:deepslate",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:cobbled_deepslate"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:cobbled_deepslate"}}] as @e[nbt={Item:{id:"minecraft:deepslate"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge


# minecraft:copper_ore
execute if entity @s[nbt={Item:{id:"minecraft:copper_ore"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:copper_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:copper_ore"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:copper_ore"}}] as @e[nbt={Item:{id:"minecraft:copper_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge


# Now since 1.19 : RAW ORES :
# minecraft:raw_copper

execute if entity @s[nbt={Item:{id:"minecraft:raw_copper"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:copper_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:raw_copper"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:raw_copper"}}] as @e[nbt={Item:{id:"minecraft:copper_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:iron_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] as @e[nbt={Item:{id:"minecraft:iron_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:iron_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:raw_iron"}}] as @e[nbt={Item:{id:"minecraft:iron_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge

execute if entity @s[nbt={Item:{id:"minecraft:raw_gold"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:gold_ingot",Count:1b},Tags:["waiting_merge"]}
execute if entity @s[nbt={Item:{id:"minecraft:raw_gold"}}] store result entity @e[type=item,sort=nearest,limit=1,tag=waiting_merge] Item.Count byte 1 run data get entity @s Item.Count
execute if entity @s[nbt={Item:{id:"minecraft:raw_gold"}}] as @e[nbt={Item:{id:"minecraft:gold_ingot"}},sort=nearest,limit=1,distance=..1] run tag @s remove waiting_merge










kill @s[nbt={Item:{id:"minecraft:cobblestone"}}]
kill @s[nbt={Item:{id:"minecraft:iron_ore"}}]
kill @s[nbt={Item:{id:"minecraft:gold_ore"}}]
kill @s[nbt={Item:{id:"minecraft:netherrack"}}]
kill @s[nbt={Item:{id:"minecraft:copper_ore"}}]

kill @s[nbt={Item:{id:"minecraft:cobbled_deepslate"}}]

kill @s[nbt={Item:{id:"minecraft:raw_copper"}}]
kill @s[nbt={Item:{id:"minecraft:raw_iron"}}]
kill @s[nbt={Item:{id:"minecraft:raw_gold"}}]




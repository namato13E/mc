function hammer:work/dig/modifiers/dig/west
function hammer:work/dig/modifiers/smelt

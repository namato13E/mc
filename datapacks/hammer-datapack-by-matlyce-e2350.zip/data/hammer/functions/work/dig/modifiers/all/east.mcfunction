function hammer:work/dig/modifiers/dig/east
function hammer:work/dig/modifiers/smelt

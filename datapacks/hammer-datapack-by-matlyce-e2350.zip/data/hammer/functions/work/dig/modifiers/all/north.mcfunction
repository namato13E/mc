function hammer:work/dig/modifiers/dig/north
function hammer:work/dig/modifiers/smelt

#say east

execute if block ~ ~1 ~1 #minecraft:break_list run setblock ~ ~1 ~1 air destroy
execute if block ~ ~ ~1 #minecraft:break_list run setblock ~ ~ ~1 air destroy
execute if block ~ ~-1 ~1 #minecraft:break_list run setblock ~ ~-1 ~1 air destroy
execute if block ~ ~1 ~-1 #minecraft:break_list run setblock ~ ~1 ~-1 air destroy
execute if block ~ ~ ~-1 #minecraft:break_list run setblock ~ ~ ~-1 air destroy
execute if block ~ ~-1 ~-1 #minecraft:break_list run setblock ~ ~-1 ~-1 air destroy
execute if block ~ ~1 ~ #minecraft:break_list run setblock ~ ~1 ~ air destroy
execute if block ~ ~-1 ~ #minecraft:break_list run setblock ~ ~-1 ~ air destroy

execute if entity @p[nbt={SelectedItem:{tag:{dig_upgrade:1b}}}] run function hammer:work/dig/modifiers/dig/east
execute if entity @p[nbt={SelectedItem:{tag:{dig_upgrade:1b}}}] run function hammer:work/dig/modifiers/dig/west

execute if entity @p[nbt={SelectedItem:{tag:{smelt_upgrade:1b}}}] as @e[type=item,distance=..4,nbt={OnGround:0b}] at @s run function hammer:work/dig/modifiers/smelt

tag @e[type=item,distance=..6,nbt={OnGround:0b}] add OnGround

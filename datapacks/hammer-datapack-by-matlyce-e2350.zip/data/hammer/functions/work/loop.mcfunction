function hammer:work/calculate

# HERE VALEUR ABSOLUE
execute if score @s rotation_x matches ..-1 run scoreboard players operation @s rotation_x *= #-1 absolue

execute if score @s break_total matches 1.. run function hammer:work/detect
# execute if entity @s[nbt={SelectedItem:{tag:{speed_upgrade:1b}}}] run effect give @s haste 1 8 true
function hammer:work/reset

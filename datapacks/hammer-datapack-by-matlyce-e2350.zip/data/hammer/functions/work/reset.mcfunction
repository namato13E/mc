
scoreboard players reset @s break_stone
scoreboard players reset @s break_andesite
scoreboard players reset @s break_diorite
scoreboard players reset @s break_granite

scoreboard players reset @s break_gravel
scoreboard players reset @s break_dirt
scoreboard players reset @s break_grass
scoreboard players reset @s break_obsidian
scoreboard players reset @s break_cobble

scoreboard players reset @s break_iron
scoreboard players reset @s break_gold
scoreboard players reset @s break_coal
scoreboard players reset @s break_diamond
scoreboard players reset @s break_emerald
scoreboard players reset @s break_redstone
scoreboard players reset @s break_lapis

scoreboard players reset @s break_netherrack
scoreboard players reset @s break_nethergold
scoreboard players reset @s break_quartz_ore
scoreboard players reset @s break_netherbric
scoreboard players reset @s break_redbrick
scoreboard players reset @s break_wartblock
scoreboard players reset @s break_basalt

scoreboard players reset @s break_cobbled_ds
scoreboard players reset @s break_tuff
scoreboard players reset @s break_ds_iro_ore
scoreboard players reset @s break_ds_gol_ore
scoreboard players reset @s break_ds_coa_ore
scoreboard players reset @s break_ds_dia_ore
scoreboard players reset @s break_ds_cop_ore
scoreboard players reset @s break_ds_eme_ore
scoreboard players reset @s break_ds_red_ore
scoreboard players reset @s break_chi_ds
scoreboard players reset @s break_ds_lap_ore
scoreboard players reset @s break_ds_brick
scoreboard players reset @s break_cr_ds_br
scoreboard players reset @s break_pol_ds
scoreboard players reset @s break_ds

# END
scoreboard players reset @s break_endst


scoreboard players set @s break_total 0

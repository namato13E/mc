execute as @e[type=item,distance=..10] at @s if data entity @s {OnGround:1b} run tag @s add OnGround

execute if score @s rotation_x matches 136..224 if score @s rotation_y matches -24..23 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/north
execute if score @s rotation_x matches 226..314 if score @s rotation_y matches -24..23 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/east
execute if score @s rotation_x matches 46..134 if score @s rotation_y matches -24..23 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/west
execute if score @s rotation_x matches 316..360 if score @s rotation_y matches -24..23 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/south
execute if score @s rotation_x matches 0..44 if score @s rotation_y matches -24..23 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/south


execute if score @s rotation_y matches 24..90 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/down
execute if score @s rotation_y matches -90..-24 positioned ^ ^ ^0.5 as @e[type=item,distance=..8,sort=nearest,limit=1,tag=!OnGround] at @s run function hammer:work/dig/up

kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:netherrack"}},distance=..8]